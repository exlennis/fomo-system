#!/usr/bin/env python3

import os
import sys

# Get the absolute path to the project root
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

from fomo_renamer.cli import main
if __name__ == "__main__":
    main()

