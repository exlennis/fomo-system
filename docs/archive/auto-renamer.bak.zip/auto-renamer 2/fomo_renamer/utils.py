"""
Utility functions for the FOMO Renamer script.

This module provides utility functions for logging, conflict resolution,
progress tracking, and report generation.
"""

import os
import sys
import logging
import json
from typing import Any, Dict, Optional
from datetime import datetime
from pathlib import Path
import traceback
from tqdm import tqdm


def setup_logging(verbose: bool = False) -> None:
    """
    Configure logging settings for the application.

    Args:
        verbose: If True, sets logging level to DEBUG, otherwise to INFO

    Returns:
        None
    """
    log_level = logging.DEBUG if verbose else logging.INFO

    # Create formatter for logs
    log_format = "%(asctime)s - %(levelname)s - %(message)s"
    date_format = "%Y-%m-%d %H:%M:%S"
    formatter = logging.Formatter(log_format, date_format)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Clear any existing handlers
    if root_logger.handlers:
        for handler in root_logger.handlers:
            root_logger.removeHandler(handler)

    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(log_level)
    root_logger.addHandler(console_handler)

    # Add file handler for persistent logs
    try:
        log_dir = Path(os.path.expanduser("~/.fomo-renamer/logs"))
        log_dir.mkdir(parents=True, exist_ok=True)

        log_filename = f"fomo-renamer-{datetime.now().strftime('%Y%m%d')}.log"
        log_file = log_dir / log_filename
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        root_logger.addHandler(file_handler)

        logging.debug(f"Log file created at {log_file}")
    except Exception as e:
        logging.warning(f"Could not create log file: {e}")
        logging.debug(traceback.format_exc())

    logging.info("Logging system initialized")
    if verbose:
        logging.debug("Verbose logging enabled")


def resolve_conflict(path: str, dry_run: bool = False) -> str:
    """
    Resolve filename conflicts by adding a numerical suffix.

    When a file with the same name already exists, this function appends
    a numerical suffix to create a unique filename.

    Args:
        path: The file path that has a conflict
        dry_run: If True, simulates conflict resolution
        without checking actual files

    Returns:
        str: A new path with a numerical suffix to avoid conflicts

    Example:
        If "file.txt" exists, returns "file_1.txt"
        If "file_1.txt" also exists, returns "file_2.txt"
    """
    if not path:
        raise ValueError("Path cannot be empty")

    path_obj = Path(path)

    # Extract components
    parent_dir = path_obj.parent
    stem = path_obj.stem
    suffix = path_obj.suffix

    # If dry run or the file doesn't exist, return the original path
    if dry_run or not path_obj.exists():
        return str(path_obj)

    counter = 1
    new_path = Path(parent_dir) / f"{stem}_{counter}{suffix}"

    # Increment counter until we find a filename that doesn't exist
    while new_path.exists():
        counter += 1
        new_path = Path(parent_dir) / f"{stem}_{counter}{suffix}"

        # Safety check to prevent infinite loops in extreme cases
        if counter > 9999:
            logging.error(
                f"Could not resolve conflict for {path} after 9999 attempts"
            )
            raise RuntimeError(
                f"Could not resolve conflict for {path} after 9999 attempts"
            )

    logging.debug(f"Resolved conflict: {path} -> {new_path}")
    return str(new_path)


def setup_progress_bar(total: int, desc: str = "") -> Any:
    """
    Create and configure a progress bar for tracking operations.

    Args:
        total: Total number of items to process
        desc: Description text to show next to the progress bar

    Returns:
        tqdm: Configured progress bar object

    Example:
        pbar = setup_progress_bar(100, "Processing files")
        for i in range(100):
            # do work
            pbar.update(1)
        pbar.close()
    """
    try:
        # Configure progress bar with sensible defaults
        progress_bar = tqdm(
            total=total,
            desc=desc,
            unit="file",
            unit_scale=True,
            bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} "
                       "[{elapsed}<{remaining}]",
        )
        return progress_bar
    except Exception as e:
        logging.warning(f"Could not create progress bar: {e}")
        logging.debug(traceback.format_exc())

        # Return a dummy object with update and close methods
        # that do nothing, so the code still works without progress bars
        class DummyProgressBar:
            def update(self, *args, **kwargs):
                pass

            def close(self):
                pass

            def set_description(self, desc):
                pass

        return DummyProgressBar()


def generate_report(
    results: Dict[str, Any],
    output_path: Optional[str] = None
) -> None:
    """
    Generate a summary report of rename operations.

    Creates a detailed report of all rename operations, including
    successful renames, skipped files, and errors.

    Args:
        results: Dictionary containing rename operation results
        output_path: Optional path to save the report (JSON format).
                    If None, prints to console only.

    Returns:
        None

    Example results format:
    {
        "total_files": 100,
        "renamed": 80,
        "skipped": 15,
        "errors": 5,
        "file_operations": [
            {
                "original": "file1.txt",
                "new": "file1-20230101.txt",
                "status": "success"
            },
            {
                "original": "file2.txt",
                "status": "error",
                "error": "Permission denied"
            }
        ]
    }
    """
    if not results:
        logging.warning("No results provided for report generation")
        return

    # Calculate summary statistics
    total = results.get("total_files", 0)
    renamed = results.get("renamed", 0)
    skipped = results.get("skipped", 0)
    errors = results.get("errors", 0)

    # Create report header
    report = [
        "\n" + "=" * 60,
        "FOMO RENAMER OPERATION REPORT",
        "=" * 60,
        f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"Total files processed: {total}",
        f"Successfully renamed: {renamed} "
        f"({(renamed/total*100 if total > 0 else 0):.1f}%)",
        f"Skipped files: {skipped}",
        f"Errors: {errors}",
        "-" * 60,
    ]

    # Add file operations details
    if "file_operations" in results:
        report.append("FILE OPERATIONS DETAILS:")
        for op in results["file_operations"]:
            if op.get("status") == "success":
                report.append(f"✓ {op.get('original')} -> {op.get('new')}")
            elif op.get("status") == "skipped":
                report.append(
                    f"⧖ {op.get('original')} "
                    f"(skipped: {op.get('reason', 'No reason provided')})"
                )
            elif op.get("status") == "error":
                report.append(
                    f"✗ {op.get('original')} "
                    f"(error: {op.get('error', 'Unknown error')})"
                )

    # Print report to console
    print("\n".join(report))

    # Save to file if output path provided
    if output_path:
        try:
            # Include timestamp in filename if not specified
            if not output_path.lower().endswith(".json"):
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = f"{output_path}_report_{timestamp}.json"

            # Create parent directories if they don't exist
            output_dir = os.path.dirname(output_path)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)

            with open(output_path, "w") as f:
                # Add metadata to the results
                results["report_generated"] = datetime.now().isoformat()
                json.dump(results, f, indent=2)

            logging.info(f"Report saved to {output_path}")
            print(f"Report saved to {output_path}")

        except Exception as e:
            logging.error(f"Failed to save report to {output_path}: {e}")
            logging.debug(traceback.format_exc())
            print(f"Error: Could not save report to {output_path}")
            