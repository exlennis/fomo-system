"""
File processing operations for the FOMO Renamer system.

This module contains functions for processing files and directories,
including backup creation, file renaming, and directory traversal.
"""

import os
import shutil
import logging
from typing import Dict, Any

# Import detectors module if needed for specific functionality
# Currently not used directly in this file, so commented out
# from . import detectors
from . import normalisers
from . import utils


def create_backup(path: str) -> str:
    """
    Create a backup of the specified file.

    Args:
        path: The path to the file to backup

    Returns:
        The path to the backup file

    Raises:
        FileNotFoundError: If the source file doesn't exist
        PermissionError: If there are permission issues
        OSError: For other OS-related errors
    """
    try:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Cannot create backup of non-existent file: {path}")

        backup_path = f"{path}.bak"
        
        # If backup already exists, create a numbered backup
        if os.path.exists(backup_path):
            counter = 1
            while os.path.exists(f"{backup_path}.{counter}"):
                counter += 1
            backup_path = f"{backup_path}.{counter}"
        
        shutil.copy2(path, backup_path)
        logging.info(f"Created backup: {backup_path}")
        return backup_path
    
    except FileNotFoundError as e:
        logging.error(f"Backup failed - File not found: {e}")
        raise
    except PermissionError as e:
        logging.error(f"Backup failed - Permission denied: {e}")
        raise
    except OSError as e:
        logging.error(f"Backup failed - OS error: {e}")
        raise


def process_file(
    filepath: str, 
    config: Dict[str, Any], 
    dry_run: bool = False, 
    backup: bool = False, 
    add_date: bool = True, 
    add_version: bool = True, 
    preserve_pattern: bool = False
) -> Dict[str, Any]:
    """
    Process an individual file by renaming it according to FOMO standards.

    Args:
        filepath: Path to the file to process
        config: Configuration dictionary
        dry_run: If True, only simulates the renaming without actually changing files
        backup: If True, creates a backup of the original file before renaming
        add_date: If True, adds date to the filename if not present
        add_version: If True, adds version to the filename if not present
        preserve_pattern: If True, preserves the detected pattern in the filename

    Returns:
        A dictionary containing the results of the processing:
        {
            'original_path': Original file path,
            'new_path': New file path after renaming,
            'success': Boolean indicating if renaming was successful,
            'skipped': Boolean indicating if the file was skipped,
            'error': Error message if any error occurred,
            'backup_path': Path to the backup file if created
        }

    Raises:
        Various OS errors during file operations (captured in return dict)
    """
    result = _initialize_result(filepath)

    # Check if file exists and is valid
    valid, result = _validate_file(filepath, result)
    if not valid:
        return result

    # Extract path components and normalize the filename
    directory, filename = os.path.split(filepath)
    name, ext = os.path.splitext(filename)

    normalized_result = _normalize_filename(name, ext, filename, filepath, config, 
                                          add_date, add_version, preserve_pattern, result)
    if normalized_result['skipped']:
        return normalized_result

    # Create and process the new filepath
    new_filepath = os.path.join(directory, normalized_result['normalized_filename'])
    result['new_path'] = _handle_filename_conflict(filepath, new_filepath, dry_run)

    # Create backup if requested
    if backup and not dry_run:
        backup_result = _create_backup_if_needed(filepath, result)
        if backup_result['skipped']:
            return backup_result

    # Perform the rename operation
    return _perform_rename(filepath, result['new_path'], dry_run, result)


def _initialize_result(filepath: str) -> Dict[str, Any]:
    """Initialize the result dictionary with default values."""
    return {
        'original_path': filepath,
        'new_path': None,
        'success': False,
        'skipped': False,
        'error': None,
        'backup_path': None
    }


def _validate_file(filepath: str, result: Dict[str, Any]) -> tuple:
    """Validate that the file exists and is a file."""
    if not os.path.exists(filepath):
        result['error'] = f"File not found: {filepath}"
        result['skipped'] = True
        logging.warning(f"Skipping non-existent file: {filepath}")
        return False, result

    if not os.path.isfile(filepath):
        result['error'] = f"Not a file: {filepath}"
        result['skipped'] = True
        logging.warning(f"Skipping non-file: {filepath}")
        return False, result

    return True, result


def _normalize_filename(name: str, ext: str, filename: str, filepath: str, 
                       config: Dict[str, Any], add_date: bool, add_version: bool, 
                       preserve_pattern: bool, result: Dict[str, Any]) -> Dict[str, Any]:
    """Normalize the filename and handle any errors."""
    try:
        normalized_filename = normalisers.normalize_filename(
            name, ext, config, add_date, add_version, preserve_pattern
        )

        # If the filename is already normalized, skip it
        if filename == normalized_filename:
            result['skipped'] = True
            result['new_path'] = filepath
            logging.info(f"Skipping already normalized file: {filepath}")
            return result

        result['normalized_filename'] = normalized_filename
        return result

    except Exception as e:
        result['error'] = f"Normalization error: {str(e)}"
        result['skipped'] = True
        logging.error(f"Error normalizing filename {filename}: {e}")
        return result


def _handle_filename_conflict(filepath: str, new_filepath: str, dry_run: bool) -> str:
    """Handle conflicts if the new file already exists."""
    if os.path.exists(new_filepath) and filepath != new_filepath:
        return utils.resolve_conflict(new_filepath, dry_run)
    return new_filepath


def _create_backup_if_needed(filepath: str, result: Dict[str, Any]) -> Dict[str, Any]:
    """Create a backup of the file if requested."""
    try:
        result['backup_path'] = create_backup(filepath)
        return result
    except Exception as e:
        result['error'] = f"Backup error: {str(e)}"
        result['skipped'] = True
        logging.error(f"Failed to create backup for {filepath}: {e}")
        return result


def _perform_rename(filepath: str, new_filepath: str, dry_run: bool, 
                   result: Dict[str, Any]) -> Dict[str, Any]:
    """Perform the actual rename operation or simulate it in dry run mode."""
    try:
        if not dry_run:
            os.rename(filepath, new_filepath)
            result['success'] = True
            logging.info(f"Renamed: {filepath} -> {new_filepath}")
        else:
            result['success'] = True
            logging.info(f"[DRY RUN] Would rename: {filepath} -> {new_filepath}")
        return result
    except Exception as e:
        result['error'] = f"Rename error: {str(e)}"
        logging.error(f"Failed to rename {filepath}: {e}")
        return result


def process_directory(
    directory: str, 
    config: Dict[str, Any], 
    dry_run: bool = False, 
    backup: bool = False, 
    recursive: bool = False, 
    add_date: bool = True, 
    add_version: bool = True, 
    preserve_pattern: bool = False
) -> Dict[str, Any]:
    """
    Process all files in a directory by renaming them according to FOMO standards.

    Args:
        directory: Path to the directory to process
        config: Configuration dictionary
        dry_run: If True, only simulates the renaming without actually changing files
        backup: If True, creates a backup of the original files before renaming
        recursive: If True, processes files in subdirectories recursively
        add_date: If True, adds date to the filename if not present
        add_version: If True, adds version to the filename if not present
        preserve_pattern: If True, preserves the detected pattern in the filename

    Returns:
        A dictionary containing the results of the processing:
        {
            'total_files': Total number of files processed,
            'renamed': Number of files successfully renamed,
            'skipped': Number of files skipped,
            'errors': Number of files with errors,
            'results': List of individual file processing results,
            'directories_processed': List of directories processed
        }

    Raises:
        FileNotFoundError: If the directory doesn't exist
        NotADirectoryError: If the path is not a directory
        PermissionError: If there are permission issues
    """
    # Validate directory
    _validate_directory(directory)

    results = _initialize_directory_results(directory)

    try:
        # Collect files and directories
        files_to_process, dirs_processed = _collect_files_and_dirs(directory, recursive)

        # Update results with collected directories
        results['directories_processed'].extend(list(dirs_processed))

        # Process files and update results
        _process_files(
            files_to_process, 
            config, 
            dry_run, 
            backup, 
            add_date, 
            add_version, 
            preserve_pattern, 
            results
        )

        # Log summary
        _log_directory_results(directory, results)

        return results

    except PermissionError as e:
        logging.error(f"Permission error accessing directory {directory}: {e}")
        raise
    except Exception as e:
        logging.error(f"Unexpected error processing directory {directory}: {e}")
        raise


def _validate_directory(directory: str) -> None:
    """Validate that the directory exists and is a directory."""
    if not os.path.exists(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")

    if not os.path.isdir(directory):
        raise NotADirectoryError(f"Not a directory: {directory}")


def _initialize_directory_results(directory: str) -> Dict[str, Any]:
    """Initialize the results dictionary with default values."""
    return {
        'total_files': 0,
        'renamed': 0,
        'skipped': 0,
        'errors': 0,
        'results': [],
        'directories_processed': [directory]
    }


def _collect_files_and_dirs(directory: str, recursive: bool) -> tuple:
    """Collect files to process and directories processed."""
    files_to_process = []
    dirs_processed = set()

    if recursive:
        for root, dirs, files in os.walk(directory):
            for file in files:
                files_to_process.append(os.path.join(root, file))
            dirs_processed.update([os.path.join(directory, d) for d in dirs])
    else:
        for item in os.listdir(directory):
            item_path = os.path.join(directory, item)
            if os.path.isfile(item_path):
                files_to_process.append(item_path)

    return files_to_process, dirs_processed


def _process_files(
    files_to_process: list, 
    config: Dict[str, Any], 
    dry_run: bool, 
    backup: bool, 
    add_date: bool, 
    add_version: bool, 
    preserve_pattern: bool, 
    results: Dict[str, Any]
) -> None:
    """Process each file and update the results dictionary."""
    # Setup progress bar
    results['total_files'] = len(files_to_process)
    progress_bar = utils.setup_progress_bar(results['total_files'], "Processing files")

    # Process each file
    for filepath in files_to_process:
        file_result = process_file(
            filepath=filepath,
            config=config,
            dry_run=dry_run,
            backup=backup,
            add_date=add_date,
            add_version=add_version,
            preserve_pattern=preserve_pattern
        )

        results['results'].append(file_result)

        # Update statistics
        if file_result['success'] and not file_result['skipped']:
            results['renamed'] += 1
        elif file_result['skipped']:
            results['skipped'] += 1
        else:
            results['errors'] += 1

        # Update progress bar
        if progress_bar:
            progress_bar.update(1)

    # Close progress bar
    if progress_bar:
        progress_bar.close()


def _log_directory_results(directory: str, results: Dict[str, Any]) -> None:
    """Log the directory processing results."""
    logging.info(f"Directory processing complete: {directory}")
    logging.info(f"Total files: {results['total_files']}")
    logging.info(f"Renamed: {results['renamed']}")
    logging.info(f"Skipped: {results['skipped']}")
    logging.info(f"Errors: {results['errors']}")

