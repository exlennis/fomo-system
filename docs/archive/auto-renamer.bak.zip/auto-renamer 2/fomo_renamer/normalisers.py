"""
Normalisers module for the FOMO Renamer system.

This module provides functions for normalizing filenames according to the FOMO standard.
It includes functions for converting text to kebab-case, extracting components from filenames,
and applying normalization patterns to create standardized filenames.
"""

import os
import re
import logging
from typing import Dict, Any

from .detectors import detect_date, detect_version, detect_file_type

logger = logging.getLogger(__name__)


def to_kebab_case(text: str) -> str:
    """
    Convert text to kebab-case format.
    
    Args:
        text (str): The input text to convert
        
    Returns:
        str: The kebab-case formatted text
        
    Examples:
        >>> to_kebab_case("Hello World")
        'hello-world'
        >>> to_kebab_case("Final_Report_2023")
        'final-report-2023'
    """
    try:
        # Replace special characters with spaces
        text = re.sub(r'[^\w\s]', ' ', text)
        
        # Replace underscores and multiple spaces with a single space
        text = re.sub(r'[_\s]+', ' ', text)
        
        # Convert to lowercase, strip leading/trailing spaces, and replace spaces with hyphens
        result = '-'.join(text.lower().strip().split())
        
        # Remove any duplicate hyphens that might have been created
        result = re.sub(r'-+', '-', result)
        
        return result
    except Exception as e:
        logger.error(f"Error converting text to kebab-case: {e}")
        return text  # Return original text if conversion fails


def extract_filename_components(filename: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract components (name, date, version) from a filename.
    
    Args:
        filename (str): The filename to analyze (without extension)
        config (dict): Configuration dictionary containing patterns and settings
        
    Returns:
        dict: Dictionary containing the extracted components:
              - name: Base name of the file
              - date: Detected date (if any)
              - version: Detected version (if any)
              - file_type: Detected file type
              
    Examples:
        >>> extract_filename_components("report-20230314-v02", config)
        {'name': 'report', 'date': '20230314', 'version': 2, 'file_type': 'document'}
    """
    try:
        # Get file extension and name separately
        base_name, ext = os.path.splitext(filename)
        if ext:
            # If filename includes extension, remove it for processing
            ext = ext.lower()
        
        # Detect date in the filename
        date = detect_date(base_name)
        
        # Remove date from filename if found
        if date:
            # Remove various date formats from the name
            date_patterns = [
                date,
                re.sub(r'(\d{4})(\d{2})(\d{2})', r'\1-\2-\3', date),
                re.sub(r'(\d{4})(\d{2})(\d{2})', r'\1_\2_\3', date)
            ]
            for pattern in date_patterns:
                base_name = re.sub(f'[-_]?{pattern}[-_]?', '-', base_name)
        
        # Detect version in the filename
        version = detect_version(base_name)
        
        # Remove version from filename if found
        if version is not None:
            # Remove common version patterns
            base_name = re.sub(r'[-_]?v\d+[-_]?', '-', base_name)
            base_name = re.sub(r'[-_]?version\s*\d+[-_]?', '-', base_name)
        
        # Clean up any artifacts from removals
        base_name = re.sub(r'-+', '-', base_name)
        base_name = base_name.strip('-_')
        
        # Detect file type using the original filename with extension
        file_type = detect_file_type(filename, config)
        
        return {
            'name': base_name,
            'date': date,
            'version': version,
            'file_type': file_type,
            'ext': ext
        }
    except Exception as e:
        logger.error(f"Error extracting components from filename {filename}: {e}")
        # Return a basic structure with the original filename as name
        return {
            'name': filename,
            'date': None,
            'version': None,
            'file_type': 'default',
            'ext': ''
        }


def normalize_filename(
    filename: str, 
    ext: str, 
    config: Dict[str, Any], 
    add_date: bool = True, 
    add_version: bool = True, 
    preserve_pattern: bool = False
) -> str:
    """
    Normalize a filename according to FOMO standards and configuration.

    Args:
        filename (str): The filename to normalize (without extension)
        ext (str): The file extension, including the leading dot
        config (dict): Configuration dictionary containing patterns and settings
        add_date (bool, optional): Whether to add date to the filename. Defaults to True.
        add_version (bool, optional): Whether to add version to the filename. Defaults to True.
        preserve_pattern (bool, optional): Whether to preserve detected patterns. Defaults to False.

    Returns:
        str: Normalized filename with extension

    Examples:
        >>> normalize_filename("final report", ".docx", config)
        'doc-final-report-20230421-v01.docx'
    """
    try:
        # Extract components from the filename
        components = extract_filename_components(filename + ext, config)

        # Convert name to kebab-case unless preserve_pattern is True
        if not preserve_pattern:
            components['name'] = to_kebab_case(components['name'])

        # Get the appropriate pattern based on file type
        file_type = components['file_type']
        if file_type in config['patterns']:
            pattern = config['patterns'][file_type]
        else:
            pattern = config['patterns']['default']

        # Format the date if needed
        date_str = ''
        if add_date and components['date']:
            # Use the existing date from components
            date_str = components['date']
        elif add_date:
            # Use current date if no date found and add_date is True
            from datetime import datetime
            date_str = datetime.now().strftime(config.get('date_format', '%Y%m%d'))
        
        # Format the version if needed
        version_str = ''
        if add_version and components['version'] is not None:
            version_format = config.get('version_format', 'v{:02d}')
            version_str = version_format.format(components['version'])
        elif add_version:
            # Add default version (v01) if no version found and add_version is True
            version_format = config.get('version_format', 'v{:02d}')
            version_str = version_format.format(1)
        
        # Build the normalized filename using the pattern
        normalized = pattern.format(
            name=components['name'],
            date=date_str,
            version=version_str,
            ext=ext
        )
        
        # Clean up any artifacts (double hyphens, etc.)
        normalized = re.sub(r'-+', '-', normalized)
        normalized = re.sub(r'--', '-', normalized)
        
        # Handle empty components in the pattern
        normalized = re.sub(r'-+', '-', normalized)
        normalized = normalized.strip('-')
        
        return normalized
    except Exception as e:
        logger.error(f"Error normalizing filename {filename}: {e}")
        # Return original filename with extension if normalization fails
        return f"{filename}{ext}"

