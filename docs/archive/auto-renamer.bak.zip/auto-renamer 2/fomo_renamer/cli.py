#!/usr/bin/env python3
"""
Command-line interface for FOMO Renamer.

This module provides the command-line interface for the FOMO Renamer tool,
including argument parsing and the main entry point.
"""
import argparse
import os
import sys
from typing import Dict, Any

from .config import load_config
from .processors import process_directory, process_file
from .utils import setup_logging, generate_report


def parse_args() -> argparse.Namespace:
    """
    Parse command-line arguments for the FOMO Renamer tool.

    Returns:
        argparse.Namespace: Parsed command-line arguments.
    """
    parser = argparse.ArgumentParser(
        description="FOMO Renamer - A tool for normalizing filenames according to FOMO standards.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    parser.add_argument(
        "target",
        help="Target file or directory to process."
    )
    
    parser.add_argument(
        "-d", "--dry-run",
        action="store_true",
        help="Preview changes without making them."
    )
    
    parser.add_argument(
        "-r", "--recursive",
        action="store_true",
        help="Process files in subdirectories."
    )
    
    parser.add_argument(
        "-b", "--backup",
        action="store_true",
        help="Create backups of original files."
    )
    
    parser.add_argument(
        "--no-date",
        action="store_true",
        help="Skip adding dates to filenames."
    )
    
    parser.add_argument(
        "--no-version",
        action="store_true",
        help="Skip adding version numbers to filenames."
    )
    
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable detailed logging."
    )
    
    parser.add_argument(
        "-p", "--preserve-pattern",
        action="store_true",
        help="Maintain detected patterns in filenames."
    )
    
    parser.add_argument(
        "-c", "--config",
        help="Specify custom config file path."
    )
    
    parser.add_argument(
        "-o", "--output-report",
        help="Generate a report file with the results."
    )
    
    return parser.parse_args()


def confirm_changes(results: Dict[str, Any], dry_run: bool = False) -> bool:
    """
    Ask the user to confirm changes before proceeding.

    Args:
        results (Dict[str, Any]): Dictionary containing the results of the processing.
        dry_run (bool, optional): Whether this is a dry run. Defaults to False.

    Returns:
        bool: True if the user confirms, False otherwise.
    """
    if dry_run:
        print("\nDRY RUN MODE - No actual changes will be made.")

    renamed_count = len(results.get("renamed", []))
    skipped_count = len(results.get("skipped", []))
    error_count = len(results.get("errors", []))

    print("\nSummary of changes:")
    print(f"  - Files to be renamed: {renamed_count}")
    print(f"  - Files to be skipped: {skipped_count}")
    print(f"  - Errors encountered: {error_count}")

    if renamed_count == 0:
        print("\nNo files will be renamed.")
        return False

    # Show a preview of some of the changes
    if renamed_count > 0:
        print("\nPreview of changes:")
        preview_count = min(5, renamed_count)
        for i in range(preview_count):
            original = results["renamed"][i]["original"]
            new = results["renamed"][i]["new"]
            print(f"  - {original} -> {new}")

        if renamed_count > preview_count:
            print(f"  ... and {renamed_count - preview_count} more files")

    if not dry_run:
        while True:
            response = input("\nProceed with these changes? (y/n): ").lower()
            if response in ("y", "yes"):
                return True
            elif response in ("n", "no"):
                return False
            else:
                print("Please enter 'y' or 'n'.")
    else:
        return False  # In dry run mode, always return False to prevent actual changes


def main() -> int:
    """
    Main entry point for the FOMO Renamer tool.

    Returns:
        int: Exit code (0 for success, non-zero for errors)
    """
    try:
        args = parse_args()

        # Setup logging
        setup_logging(args.verbose)

        # Load configuration
        config = load_config(args.config)

        # Process target (file or directory)
        target_path = os.path.abspath(args.target)
        results = {}

        if os.path.isfile(target_path):
            # Process single file
            results = process_file(
                filepath=target_path,
                config=config,
                dry_run=True,  # First pass is always a dry run for confirmation
                backup=args.backup,
                add_date=not args.no_date,
                add_version=not args.no_version,
                preserve_pattern=args.preserve_pattern
            )
        elif os.path.isdir(target_path):
            # Process directory
            results = process_directory(
                directory=target_path,
                config=config,
                dry_run=True,  # First pass is always a dry run for confirmation
                backup=args.backup,
                recursive=args.recursive,
                add_date=not args.no_date,
                add_version=not args.no_version,
                preserve_pattern=args.preserve_pattern
            )
        else:
            print(f"Error: Target path '{target_path}' does not exist.")
            return 1

        # Confirm changes with user
        if confirm_changes(results, args.dry_run):
            print("\nProceeding with changes...")

            # Process again with actual changes if not in dry run mode
            if not args.dry_run:
                if os.path.isfile(target_path):
                    results = process_file(
                        filepath=target_path,
                        config=config,
                        dry_run=False,
                        backup=args.backup,
                        add_date=not args.no_date,
                        add_version=not args.no_version,
                        preserve_pattern=args.preserve_pattern
                    )
                else:
                    results = process_directory(
                        directory=target_path,
                        config=config,
                        dry_run=False,
                        backup=args.backup,
                        recursive=args.recursive,
                        add_date=not args.no_date,
                        add_version=not args.no_version,
                        preserve_pattern=args.preserve_pattern
                    )

                print("\nChanges applied successfully.")
        else:
            print("\nOperation cancelled by user.")

        # Generate report if requested
        if args.output_report:
            generate_report(results, args.output_report)
            print(f"\nReport generated at: {args.output_report}")

        # Print final summary
        renamed_count = len(results.get("renamed", []))
        skipped_count = len(results.get("skipped", []))
        error_count = len(results.get("errors", []))

        print("\nFinal summary:")
        print(f"  - Files renamed: {renamed_count}")
        print(f"  - Files skipped: {skipped_count}")
        print(f"  - Errors encountered: {error_count}")

        return 0

    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        return 130
    except Exception as e:
        print(f"\nAn unexpected error occurred: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())

