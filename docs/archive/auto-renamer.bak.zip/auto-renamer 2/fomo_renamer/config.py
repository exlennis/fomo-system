"""
Configuration handler for FOMO Renamer.

This module provides configuration functionality for the FOMO Renamer system,
including default configuration settings and functions to load custom 
configurations from JSON files.
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Optional, Any

# Set up logger
logger = logging.getLogger(__name__)

# Default configuration dictionary
DEFAULT_CONFIG: Dict[str, Any] = {
    "date_format": "%Y%m%d",
    "version_format": "v{:02d}",
    "patterns": {
        "default": "{name}-{date}-{version}{ext}",
        "image": "img-{name}-{date}-{version}{ext}",
        "document": "doc-{name}-{date}-{version}{ext}",
        "code": "{name}{ext}",
        "screenshot": "screenshot-{context}-{date}{ext}"
    },
    "file_types": {
        "image": [".jpg", ".jpeg", ".png", ".gif", ".webp"],
        "document": [".pdf", ".docx", ".xlsx", ".md", ".txt"],
        "code": [".py", ".js", ".html", ".css", ".java", ".go"],
        "screenshot": [".png", ".jpg"]
    }
}


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load configuration from a JSON file, falling back to defaults if necessary.

    This function attempts to load configuration from the specified JSON file path.
    If the path is not provided or invalid, or if there are issues with the JSON file,
    it falls back to the DEFAULT_CONFIG.

    Args:
        config_path (Optional[str]): Path to the configuration JSON file. 
                                    If None, uses DEFAULT_CONFIG.

    Returns:
        Dict[str, Any]: A dictionary containing the configuration settings, 
                        either from the JSON file or DEFAULT_CONFIG.

    Raises:
        No exceptions are raised as this function handles all errors internally
        and falls back to DEFAULT_CONFIG when needed, but errors are logged.
    
    Examples:
        >>> config = load_config()  # Uses DEFAULT_CONFIG
        >>> config = load_config("path/to/config.json")  # Loads from file
    """
    config = DEFAULT_CONFIG.copy()

    if config_path is None:
        logger.info("No configuration file specified, using default configuration")
        return config

    # Convert to Path object for better path handling
    config_file = Path(config_path)

    # Check if file exists
    if not config_file.exists():
        logger.warning(f"Configuration file not found: {config_path}, using default configuration")
        return config

    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            user_config = json.load(f)
            
        # Merge user configuration with default configuration
        # This ensures any missing keys in user_config will be available from default_config
        merge_configs(config, user_config)
        logger.info(f"Configuration loaded successfully from {config_path}")
        
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in configuration file {config_path}: {str(e)}")
        logger.warning("Using default configuration")
    except PermissionError:
        logger.error(f"Permission denied when accessing configuration file {config_path}")
        logger.warning("Using default configuration")
    except Exception as e:
        logger.error(f"Error loading configuration from {config_path}: {str(e)}")
        logger.warning("Using default configuration")

    return config


def merge_configs(base_config: Dict[str, Any], new_config: Dict[str, Any]) -> None:
    """
    Merge a new configuration dictionary into a base configuration dictionary.
    
    This function recursively updates a base configuration with values from a new
    configuration. For nested dictionaries, it performs a deep merge rather than
    simple replacement.
    
    Args:
        base_config (Dict[str, Any]): The base configuration to update
        new_config (Dict[str, Any]): The new configuration containing updates
        
    Returns:
        None: The base_config is modified in place
    """
    for key, value in new_config.items():
        # If both values are dictionaries, recursively merge them
        if key in base_config and isinstance(base_config[key], dict) and isinstance(value, dict):
            merge_configs(base_config[key], value)
        else:
            # Otherwise, just update the value
            base_config[key] = value


def create_default_config_file(output_path: str) -> bool:
    """
    Create a default configuration file at the specified path.
    
    Args:
        output_path (str): Path where the configuration file should be created
        
    Returns:
        bool: True if the file was created successfully, False otherwise
        
    Raises:
        No exceptions are raised as this function handles all errors internally,
        but errors are logged.
    """
    try:
        output_file = Path(output_path)
        
        # Create directory if it doesn't exist
        os.makedirs(output_file.parent, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
            
        logger.info(f"Default configuration file created at {output_path}")
        return True
    except Exception as e:
        logger.error(f"Failed to create default configuration file at {output_path}: {str(e)}")
        return False


def get_file_type(file_extension: str, config: Dict[str, Any]) -> str:
    """
    Determine the file type based on file extension using the configuration.
    
    Args:
        file_extension (str): The file extension including the dot (e.g., '.png')
        config (Dict[str, Any]): The configuration dictionary
        
    Returns:
        str: The file type name if found, 'default' otherwise
    """
    file_extension = file_extension.lower()
    file_types = config.get("file_types", {})
    
    for file_type, extensions in file_types.items():
        if file_extension in extensions:
            return file_type
            
    return "default"

