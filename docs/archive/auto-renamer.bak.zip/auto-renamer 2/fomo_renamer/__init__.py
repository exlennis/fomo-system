"""
FOMO Renamer - Filename Optimization and Management Organizer

A utility for normalizing filenames with standardized date and version formats.
This package provides tools to detect dates and versions in filenames, 
normalize filenames according to configurable patterns, and process files 
and directories to apply these naming conventions.

Modules:
    - detectors: Functions for detecting dates, versions, and file types
    - normalisers: Functions for normalizing filenames
    - processors: File operations and processing logic
    - utils: Helper utilities for logging, progress tracking, etc.
    - config: Configuration handling and default settings
    - cli: Command-line interface

Usage:
    from fomo_renamer import process_directory
    process_directory('/path/to/dir', config, recursive=True)
    
    # Or run via CLI
    python -m fomo_renamer.cli /path/to/dir --recursive
"""

__version__ = '0.1.0'
__author__ = 'FOMO System'
__license__ = 'MIT'

# Import and expose key functionality at the package level
from .detectors import detect_date, detect_version, detect_file_type
from .normalisers import normalize_filename, to_kebab_case, extract_filename_components
from .processors import process_file, process_directory, create_backup
from .utils import setup_logging, resolve_conflict, setup_progress_bar, generate_report
from .config import DEFAULT_CONFIG, load_config

# Define all importable names
__all__ = [
    # Version info
    '__version__', '__author__', '__license__',
    
    # Detectors
    'detect_date', 'detect_version', 'detect_file_type',
    
    # Normalisers
    'normalize_filename', 'to_kebab_case', 'extract_filename_components',
    
    # Processors
    'process_file', 'process_directory', 'create_backup',
    
    # Utils
    'setup_logging', 'resolve_conflict', 'setup_progress_bar', 'generate_report',
    
    # Config
    'DEFAULT_CONFIG', 'load_config'
]

