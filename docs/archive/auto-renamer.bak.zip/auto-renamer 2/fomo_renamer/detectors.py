#!/usr/bin/env python3
"""
File detection utilities for FOMO Renamer.

This module provides functions to detect dates, versions, and file types in filenames.
These detectors are used to extract information from existing filenames and determine
how to properly normalize them according to FOMO standards.
"""

import os
import re
import logging
from datetime import datetime
from typing import Optional, Dict, Any


def detect_date(filename: str) -> Optional[str]:
    """
    Detect and extract a date from a filename in various formats.
    
    Supported formats:
    - YYYYMMDD (e.g., 20230314)
    - YYYY-MM-DD (e.g., 2023-03-14)
    - YYYY_MM_DD (e.g., 2023_03_14)
    
    Args:
        filename: The filename to analyze for date patterns
        
    Returns:
        A standardized date string in YYYYMMDD format if found, None otherwise
        
    Examples:
        >>> detect_date("document-20230314.pdf")
        '20230314'
        >>> detect_date("notes-2023-03-14-v2.txt")
        '20230314'
        >>> detect_date("report_2023_03_14_final.docx")
        '20230314'
        >>> detect_date("no_date_here.txt")
        None
    """
    date_patterns = [
        # YYYYMMDD format
        r'(\d{4}[01]\d[0-3]\d)',
        # YYYY-MM-DD format
        r'(\d{4})-([01]\d)-([0-3]\d)',
        # YYYY_MM_DD format
        r'(\d{4})_([01]\d)_([0-3]\d)'
    ]
    
    try:
        # Check for YYYYMMDD format
        match = re.search(date_patterns[0], filename)
        if match:
            date_str = match.group(1)
            # Validate it's a legitimate date
            try:
                datetime.strptime(date_str, '%Y%m%d')
                return date_str
            except ValueError:
                logging.debug(f"Found date-like pattern {date_str} in {filename}, but it's not a valid date")
                return None
        
        # Check for YYYY-MM-DD format
        match = re.search(date_patterns[1], filename)
        if match:
            year, month, day = match.groups()
            date_str = f"{year}{month}{day}"
            # Validate it's a legitimate date
            try:
                datetime.strptime(date_str, '%Y%m%d')
                return date_str
            except ValueError:
                logging.debug(f"Found date-like pattern {year}-{month}-{day} in {filename}, but it's not a valid date")
                return None
        
        # Check for YYYY_MM_DD format
        match = re.search(date_patterns[2], filename)
        if match:
            year, month, day = match.groups()
            date_str = f"{year}{month}{day}"
            # Validate it's a legitimate date
            try:
                datetime.strptime(date_str, '%Y%m%d')
                return date_str
            except ValueError:
                logging.debug(f"Found date-like pattern {year}_{month}_{day} in {filename}, but it's not a valid date")
                return None
                
        return None
    except Exception as e:
        logging.error(f"Error detecting date in filename {filename}: {str(e)}")
        return None


def detect_version(filename: str) -> Optional[int]:
    """
    Detect and extract a version number from a filename in various formats.
    
    Supported patterns:
    - vN (e.g., v2)
    - v0N (e.g., v01)
    - _vN or -vN (e.g., _v2, -v01)
    - version N (e.g., version 2)
    
    Args:
        filename: The filename to analyze for version patterns
        
    Returns:
        The integer version number if found, None otherwise
        
    Examples:
        >>> detect_version("document-v2.pdf")
        2
        >>> detect_version("notes-v01.txt")
        1
        >>> detect_version("report_version 3.docx")
        3
        >>> detect_version("no_version_here.txt")
        None
    """
    version_patterns = [
        # vN format
        r'v(\d+)',
        # _vN or -vN format
        r'[_-]v(\d+)',
        # version N format
        r'version\s*(\d+)'
    ]
    
    try:
        # Try each pattern
        for pattern in version_patterns:
            match = re.search(pattern, filename, re.IGNORECASE)
            if match:
                version_str = match.group(1)
                # Strip leading zeros to get proper integer
                version = int(version_str.lstrip('0') or '0')
                return version
        
        return None
    except Exception as e:
        logging.error(f"Error detecting version in filename {filename}: {str(e)}")
        return None


def detect_file_type(filename: str, config: Dict[str, Any]) -> str:
    """
    Determine the file type based on extension and filename patterns.
    
    File type is determined by:
    1. Matching file extension against configured extensions
    2. Matching filename patterns (e.g., starts with "screenshot")
    
    Args:
        filename: The filename to analyze
        config: Configuration dictionary containing file type definitions
        
    Returns:
        A string indicating the file type (e.g., "image", "document", "code")
        If no match is found, returns "default"
        
    Examples:
        >>> config = {"file_types": {"image": [".jpg", ".png"], "document": [".pdf", ".docx"]}}
        >>> detect_file_type("photo.jpg", config)
        'image'
        >>> detect_file_type("report.pdf", config)
        'document'
        >>> detect_file_type("unknown.xyz", config)
        'default'
    """
    try:
        # Extract the file extension
        _, ext = os.path.splitext(filename.lower())
        
        # Check if we have file type configurations
        if not config or 'file_types' not in config:
            logging.warning("No file type configuration provided, using default")
            return "default"
        
        file_types = config.get('file_types', {})
        
        # First check based on file extension
        for file_type, extensions in file_types.items():
            if ext in extensions:
                return file_type
        
        # Special case checks based on filename patterns
        base_filename = os.path.basename(filename).lower()
        
        # Check for screenshot pattern
        if base_filename.startswith('screenshot') and ext in file_types.get('screenshot', ['.png', '.jpg']):
            return 'screenshot'
            
        # Add more special case patterns here if needed
        
        # Default fallback
        return "default"
    except Exception as e:
        logging.error(f"Error detecting file type for {filename}: {str(e)}")
        return "default"


# Helper function for testing
def test_detectors() -> None:
    """
    Run tests on detector functions with sample filenames.
    
    This function is for quick validation of the detector functions.
    """
    # Sample config for testing
    test_config = {
        "file_types": {
            "image": [".jpg", ".jpeg", ".png", ".gif", ".webp"],
            "document": [".pdf", ".docx", ".xlsx", ".md", ".txt"],
            "code": [".py", ".js", ".html", ".css", ".java", ".go"],
            "screenshot": [".png", ".jpg"]
        }
    }
    
    # Test date detection
    date_test_cases = [
        "document-20230314.pdf",
        "notes-2023-03-14-v2.txt",
        "report_2023_03_14_final.docx",
        "invalid-20231335.pdf",  # Invalid date
        "no_date_here.txt"
    ]
    
    print("Date Detection Tests:")
    for filename in date_test_cases:
        date = detect_date(filename)
        print(f"  {filename:<30} -> {date}")
    
    # Test version detection
    version_test_cases = [
        "document-v2.pdf",
        "notes-v01.txt",
        "report_v5_final.docx",
        "presentation-version 3.pptx",
        "manual_v10.pdf",
        "no_version_here.txt"
    ]
    
    print("\nVersion Detection Tests:")
    for filename in version_test_cases:
        version = detect_version(filename)
        print(f"  {filename:<30} -> {version}")
    
    # Test file type detection
    file_type_test_cases = [
        "photo.jpg",
        "report.pdf",
        "code.py",
        "notes.txt",
        "screenshot-meeting.png",
        "unknown.xyz"
    ]
    
    print("\nFile Type Detection Tests:")
    for filename in file_type_test_cases:
        file_type = detect_file_type(filename, test_config)
        print(f"  {filename:<30} -> {file_type}")


if __name__ == "__main__":
    # Set up basic logging
    logging.basicConfig(level=logging.INFO)
    
    # Run test suite if this file is executed directly
    test_detectors()

