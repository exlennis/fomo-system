# FOMO Renamer Tool

FOMO Renamer is a file organisation and renaming tool designed to standardize filenames across a project or system. It automatically detects dates, version numbers, and file types, then applies consistent naming patterns based on configurable rules.

## Features

- **Smart Detection**: Automatically identifies dates, version numbers, and file types
- **Flexible Configuration**: Customize naming patterns via JSON configuration files
- **Dry Run Mode**: Preview changes before applying them
- **Conflict Resolution**: Handles filename collisions gracefully
- **Backup Creation**: Optional backup of original files before renaming
- **Progress Tracking**: Visual indicators for large operations
- **Comprehensive Logging**: Detailed logs for troubleshooting

## Installation

### Prerequisites

- Python 3.7+
- pip (Python package manager)

### Standard Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/fomo-renamer.git
cd fomo-renamer

# Install dependencies
pip install -r requirements.txt

# Make the CLI script executable (Unix/Linux/macOS)
chmod +x fomo_renamer.py
```

### Development Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/fomo-renamer.git
cd fomo-renamer

# Create and activate a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .
```

## Usage

### Basic Usage

```bash
# Process a directory with default settings
python -m fomo_renamer /path/to/directory

# Process a directory with recursive search
python -m fomo_renamer /path/to/directory --recursive

# Preview changes without applying them (dry run)
python -m fomo_renamer /path/to/directory --dry-run
```

### Advanced Options

```bash
# Create backups of original files
python -m fomo_renamer /path/to/directory --backup

# Skip adding dates to filenames
python -m fomo_renamer /path/to/directory --no-date

# Skip adding version numbers to filenames
python -m fomo_renamer /path/to/directory --no-version

# Use a custom configuration file
python -m fomo_renamer /path/to/directory --config path/to/config.json

# Preserve any detected patterns in the original filename
python -m fomo_renamer /path/to/directory --preserve-pattern

# Enable verbose logging
python -m fomo_renamer /path/to/directory --verbose
```

### Full Command Options

```
usage:
  fomo_renamer [-h]
  fomo_renamer [--dry-run] [--recursive]
  fomo_renamer [--backup]
  fomo_renamer [--no-date] [--no-version]
  fomo_renamer [--preserve-pattern] [--verbose]
  fomo_renamer [--config CONFIG]
  fomo_renamer directory

Standardise filenames according to the FOMO naming convention.

Positional arguments:
  directory             Path to directory containing files to rename

Optional arguments:
  -h, --help            show this help message and exit
  --dry-run, -d         Preview changes without applying them
  --recursive, -r       Process files in subdirectories
  --backup, -b          Create backups of original files
  --no-date             Skip adding dates to filenames
  --no-version          Skip adding version numbers
  --preserve-pattern, -p
                        Preserve detected patterns in original filename
  --verbose, -v         Enable detailed logging
  --config CONFIG, -c CONFIG
                        Path to custom configuration file
```

## Configuration

FOMO Renamer uses a JSON configuration file to customize its behavior. You can specify your own config file with the `--config` option.

### Configuration File Format

```json
{
  "date_format": "%Y%m%d",
  "version_format": "v{:02d}",
  "patterns": {
    "default": "{name}-{date}-{version}{ext}",
    "image": "img-{name}-{date}-{version}{ext}",
    "document": "doc-{name}-{date}-{version}{ext}",
    "code": "{name}{ext}",
    "screenshot": "screenshot-{context}-{date}{ext}"
  },
  "file_types": {
    "image": [".jpg", ".jpeg", ".png", ".gif", ".webp"],
    "document": [".pdf", ".docx", ".xlsx", ".md", ".txt"],
    "code": [".py", ".js", ".html", ".css", ".java", ".go"],
    "screenshot": [".png", ".jpg"]
  }
}
```

### Configuration Options

- **date_format**: Format string for how dates should appear in filenames
- **version_format**: Format string for how version numbers should appear
- **patterns**: Mapping of file types to filename patterns
  - Available placeholders: `{name}`, `{date}`, `{version}`, `{ext}`, `{context}`
- **file_types**: Mapping of file type categories to file extensions

## Naming Patterns and Detection Logic

### Date Detection

FOMO Renamer can detect dates in filenames in various formats:

- YYYYMMDD (e.g., 20230314)
- YYYY-MM-DD (e.g., 2023-03-14)
- YYYY_MM_DD (e.g., 2023_03_14)
- MM-DD-YYYY and other regional variants

Detected dates are validated to ensure they represent actual calendar dates and are standardized to the format specified in the configuration.

### Version Detection

Version numbers are detected in several common formats:

- vN (e.g., v2)
- v0N (e.g., v01)
- _vN or -vN (e.g., _v2, -v01)
- version N (e.g., version 2)

When detected, version numbers are standardized according to the `version_format` in the configuration.

### File Type Detection

File types are determined using two methods:

1. **Extension matching**: The file extension is compared against the extensions listed in the `file_types` configuration.
2. **Pattern matching**: Certain filename patterns are recognized (e.g., filenames starting with "screenshot" are categorized as screenshots).

The detected file type determines which naming pattern from the configuration will be applied.

### Normalisation Process

1. The original filename is analysed to extract components (base name, date, version)
2. The base name is converted to kebab-case (lowercase with hyphens between words)
3. Dates and versions are standardised according to the configuration
4. The appropriate pattern for the file type is applied
5. If a resulting filename would conflict with an existing file, a numerical suffix is added

## Examples

### Before and After Examples

```
BEFORE:                       →   AFTER:
--------------------------------------------------------------------
Quarterly Report 2023.docx    →   doc-quarterly-report-20230000-v01.docx
screenshot20230405.png        →   screenshot-20230405.png
logo_v2.jpg                   →   img-logo-20000000-v02.jpg
code_backup_2023-03-15_v01.py →   code-backup-20230315-v01.py
My Document-2.pdf             →   doc-my-document-20000000-v02.pdf
meeting-notes_2023_04_01.txt  →   doc-meeting-notes-20230401-v01.txt
```

## Troubleshooting

### Common Issues

- **Files not being renamed**: Check file permissions and ensure the program has write access
- **Dates or versions not detected**: Verify the filename format matches one of the supported patterns
- **Unexpected naming results**: Check your configuration file for correct patterns

### Logging

Use the `--verbose` flag to enable detailed logging, which can help diagnose issues:

```bash
python -m fomo_renamer /path/to/directory --verbose
```

Logs include information about detected components, applied patterns, and any errors encountered.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

